package app;

import java.awt.EventQueue;

import controller.WeatherController;

/**
 * Class that starts the Vantage Pro application
 * @version Surafel Seboka
 * Group 6
 */
public final class VantageMain {
	
	
	/**
     * Private empty constructor to avoid accidental instantiation. 
     */
	private VantageMain() { };
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
				
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					WeatherController window = new WeatherController();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
}
